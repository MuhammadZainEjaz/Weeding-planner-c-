#include <iostream>
#include <fstream>
#include "Planner.h"

using namespace std;

int main()
{
	MyPlan p1;
	p1.menu();
	return 0;
}