#include <iostream>
#include "Budget.h"
using namespace std;

Budget::Budget()
{
	budget = 0;
	flag = true;
}

double Budget::getBudget() const
{
	return budget;
}

bool Budget::isBudgetAvailable() const
{
	if (flag == true)
	{
		return true;
	}
	else
		return false;
}

void Budget::setBudget(double val)
{
	budget = val;
}

void Budget::setFlag(bool flag_)
{
	flag = flag_;
}

double Budget::getPercentageOfBudget(double percentage) const
{
	return (budget * percentage) / 100;
}

void Budget::subtractFromBudget(double value)
{
	if (budget >= value)
		budget -= value;
	if (budget == 0)
		setFlag(false);
}

void Budget::addIntoBudget(double value)
{
	budget += value;
}

Budget::~Budget()
{
}