#include <iostream>
#include <windows.h>
#include <fstream>
#include "AddToCartMode.h"
using namespace std;


void AddToCartMode::menu(ofstream &fout)
{
	int choice = 0;
	char choiceC;

	// Welcome Note
	cout << "Welcome To Add to Cart mode\n";
	Sleep(3000);
	system("cls");
	
	// Deciding Venue
	for (;;)
	{
		cout << "Enter 1 for Marriage Halls OR Enter 2 for Catering: ";
		cin >> choice;
		if (choice == 1)
		{
			Wedding_halls(fout);
			break;
		}
		else if (choice == 2)
		{
			catering(fout);
			break;
		}
		else
			cout << "Invalid Input. Input Again\n";
	}
	system("cls");
	// Decision about saloons
	cout << "Want to add Saloons details?(Y for yes, N for no): ";
	cin >> choiceC;
	system("cls");
	if (choiceC == 'y' || choiceC == 'Y')
		salons(fout);
	system("cls");

	// Decision about Movie and Photography
	cout << "Want to add Movie and Photography details?(Y for yes, N for no): ";
	cin >> choiceC;
	system("cls");
	if (choiceC == 'y' || choiceC == 'Y')
		phAndMM(fout);
	system("cls");

	// Decision about Dresses
	cout << "Want to add Dresses details?(Y for yes, N for no): ";
	cin >> choiceC;
	system("cls");
	if (choiceC == 'y' || choiceC == 'Y')
		dresses(fout);
	system("cls");

	// Decision about Invitation Cards
	cout << "Want to add Invitation Cards details?(Y for yes, N for no): ";
	cin >> choiceC;
	system("cls");
	if (choiceC == 'y' || choiceC == 'Y')
		invitation_cards(fout);
	system("cls");

	// Decision about Hotel Rooms
	cout << "Want to add Hotel Rooms details?(Y for yes, N for no): ";
	cin >> choiceC;
	system("cls");
	if (choiceC == 'y' || choiceC == 'Y')
		Hotel_rooms(fout);
	system("cls");

	// Decision about Florists
	cout << "Want to add Florists details?(Y for yes, N for no): ";
	cin >> choiceC;
	system("cls");
	if (choiceC == 'y' || choiceC == 'Y')
		florists(fout);
	system("cls");

	// Decision about Bands
	cout << "Want to add Bands details?(Y for yes, N for no): ";
	cin >> choiceC;
	system("cls");
	if (choiceC == 'y' || choiceC == 'Y')
		bands(fout);
	system("cls");

	// Decision about Transportation
	cout << "Want to add Transportation details?(Y for yes, N for no): ";
	cin >> choiceC;
	system("cls");
	if (choiceC == 'y' || choiceC == 'Y')
		Transportation(fout);
	system("cls");
	OutputTotalToFile(fout);
	
	cout << "Thanks for using our services\n";
}

double * AddToCartMode::countrecords(ifstream &fin, char * nameoffile, int & numberOfRecords, int recordlength, int tosubtract)
{
	char arr[150];
	fin.open(nameoffile);
	for (numberOfRecords = 0; !fin.eof(); numberOfRecords++)
	{
		fin.getline(arr, 149);
	}
	fin.close();
	fin.open(nameoffile);
	numberOfRecords -= tosubtract;
	numberOfRecords /= recordlength;
	double *price = new double[numberOfRecords];
	return price;
}


void AddToCartMode::Wedding_halls(ofstream &fout)
{
	fout << "Hall Details:\n";
	int hall_selection = 0, No_of_people = 0, numberOfRecords=0;
	double *price;
	char arr[150], y_n;

	ifstream fin;

	price = countrecords(fin, "halls.txt", numberOfRecords, 8);

	for (int j = 0; j < numberOfRecords; j++)
	{
		cout << "Option no: " << j + 1 << "\n";
		cout << "Name: ";
		fin.getline(arr, 149);
		cout << arr << "\n";
		cout << "Address: ";
		fin.getline(arr, 149);
		cout << arr << "\n";
		cout << "Price Per Head(Rs.): ";
		fin >> price[j];
		fin.ignore();
		cout << price[j] << "\n";
		cout << "Description: ";
		fin.getline(arr, 149);
		cout << arr << "\n";
		cout << "Contact No: ";
		fin.getline(arr, 149);
		cout << arr << "\n";
		cout << "Stars: ";
		fin.getline(arr, 149);
		cout << arr << "\n";
		cout << "Rating: ";
		fin.getline(arr, 149);
		cout << arr << "\n";
		fin.getline(arr, 149);
		cout << arr << "\n";
	}
	fin.close();
	cout << "Which Option You liked: ";
	cin >> hall_selection;
	cout << "How many people are invited?: ";
	cin >> No_of_people;
	cart.addANewEntry(price[hall_selection - 1] * No_of_people);
	cout << "Total Price: " << price[hall_selection - 1] * No_of_people << "\n";
	cout << "Are you satisfied? Should we add it to cart?(Y for yess, N for no): ";
	cin >> y_n;
	if (y_n == 'y' || y_n == 'Y')
	{
		
		fin.open("halls.txt");
		for (int j = 0; j <= hall_selection; j++)
		{
			if (j == hall_selection - 1)
			{
				fout << "Name: ";
				fin.getline(arr, 149);
				fout << arr << "\n";
				fout << "Address: ";
				fin.getline(arr, 149);
				fout << arr << "\n";
				fout << "Price Per Head(Rs.): ";
				fin >> price[j];
				fin.ignore();
				fout << price[j] << "\n";
				fout << "Description: ";
				fin.getline(arr, 149);
				fout << arr << "\n";
				fout << "Contact No: ";
				fin.getline(arr, 149);
				fout << arr << "\n";
				fout << "Stars: ";
				fin.getline(arr, 149);
				fout << arr << "\n";
				fout << "Rating: ";
				fin.getline(arr, 149);
				fout << arr << "\n";
				fin.getline(arr, 149);
				fout << arr << "\n";
				break;
			}
			else
			{
				for (int i = 0; i < 8; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fout << "Total amount for Halls is: " << cart.returnCurrentVal() << "\n";
		fout << arr << "\n";
		fin.close();
	}
	delete[] price;
}

void AddToCartMode::catering(ofstream &fout)
{
	double *price_items, grandTotal = 0, total[53];
	int quantity[53] , numberofrecords=0;
	char **arr, options, temp[100];
	ifstream fin;
	price_items = countrecords(fin, "Wedding_items.txt", numberofrecords, 2);
	arr = new char*[numberofrecords];
	for (int i = 0; i < numberofrecords; i++)
	{
		arr[i] = new char[100];
		fin.getline(arr[i], 99);
		fin >> price_items[i];
		fin.ignore();
		cout << "Item: " << arr[i] << "\n" << "Price per unit Item: " << price_items[i] << "\n";
		if (i < 18)
		{
			cout << "How much you want : ";
			cin >> quantity[i];
			quantity[i] = 10;
			cout << "Total Price for " << arr[i] << " is " << price_items[i] * quantity[i] << "\n\n";
			total[i] = price_items[i] * quantity[i];
		}
		else
		{
			total[i] = price_items[i];
			quantity[i] = 1;
		}
	}
	for (int i = 0; i < numberofrecords; i++)
	{
		grandTotal += total[i];
	}
	cout << "Your Total Expence is: " << grandTotal << "\nAre you satisfied should we add it to cart(Y for yes, N for no)\n";
	cin >> options;
	if (options == 'Y' || options == 'y')
	{
		cart.addANewEntry(grandTotal);
		fout << "Catering Details:\n";
		for (int i = 0; i < numberofrecords; i++)
		{
			fout << "Item: " << arr[i] << "   Price per Item: " << price_items[i] << "   Quantity: " << quantity[i] << "   Total Price: " << total[i] << "\n";
		}
		fout << "-------------------------------\nTotal amount: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	}
	else if (options == 'N' || options == 'n')
	{
		fout << "Total amount: 0 You didn't added it to cart.\n";
	}
	for (int i = 0; i < numberofrecords; i++)
	{
		delete[]arr[i];
	}
	delete[]arr;
	delete[]price_items;
}
// --------------------------------------------SALOONS----------------------------------------------------------------------------
void AddToCartMode::salons(ofstream &fout)
{
	fout << "\n\nSalons:\n";
	int class_salons = 0;
	double **price;
	int salon_selection = 0, total = 0, numberofrecords;
	char options = '\0', temp[100];
	ifstream fin;
	cout << "Now its Time to Finalize your salon\n";
	fin.open("salons.txt");
	for (numberofrecords = 0; !fin.eof(); numberofrecords++)
	{
		fin.getline(temp, 99);
	}
	numberofrecords /= 9;
	fin.close();
	fin.open("salons.txt");
	price = new double*[numberofrecords];
	for (int j = 0; j < numberofrecords; j++)
	{
		price[j] = new double[3];
		cout << "Option no. " << j + 1 << "\n";
		fin.getline(temp, 149);
		cout << "Name: ";
		cout << temp << "\n";
		fin.getline(temp, 149);
		cout << "Address: ";
		cout << temp << "\n";
		fin >> price[j][0];
		cout << "Price for Mehndi Make-up: ";
		cout << price[j][0] << "\n";
		fin >> price[j][1];
		cout << "Price for Barat Make-up: ";
		cout << price[j][1] << "\n";
		fin >> price[j][2];
		fin.ignore();
		cout << "Price for Walima Make-up: ";
		cout << price[j][2] << "\n";
		fin.getline(temp, 149);
		cout << "Contact No: ";
		cout << temp << "\n";
		fin.getline(temp, 149);
		cout << "Stars: ";
		cout << temp << "\n";
		fin.getline(temp, 149);
		cout << "Rating: ";
		cout << temp << "\n";
		fin.getline(temp, 149);
		cout << temp << "\n";
	}
	fin.close();
	fin.open("salons.txt");
	cout << "Which Option You liked: ";
	cin >> salon_selection;
	system("cls");
	salon_selection--;

	for (int j = 0; j < numberofrecords; j++)
	{
		if (j == salon_selection)
		{
			cout << "Option no. " << j + 1 << "\n";
			fin.getline(temp, 149);
			cout << "Name: ";
			cout << temp << "\n";
			fin.getline(temp, 149);
			cout << "Address: ";
			cout << temp << "\n";
			fin >> price[j][0];
			cout << "Price for Mehndi Make-up: ";
			cout << price[j][0] << "\n";
			fin >> price[j][1];
			cout << "Price for Barat Make-up: ";
			cout << price[j][1] << "\n";
			fin >> price[j][2];
			fin.ignore();
			cout << "Price for Walima Make-up: ";
			cout << price[j][2] << "\n";
			fin.getline(temp, 149);
			cout << "Contact No: ";
			cout << temp << "\n";
			fin.getline(temp, 149);
			cout << "Stars: ";
			cout << temp << "\n";
			fin.getline(temp, 149);
			cout << "Rating: ";
			cout << temp << "\n";
			fin.getline(temp, 149);
			cout << temp << "\n";
			cout << "Total price will be: " << price[j][0] + price[j][1] + price[j][2] << "\n";
			break;
		}
		else
		{
			for (int i = 0; i < 9; i++)
			{
				fin.getline(temp, 99);
			}
		}
	}

	cout << "Want to add it? (Y for Yes, N for No): ";
	cin >> options;
	if (options == 'N' || options == 'n')
	{
		fout << "You didn't add any Saloon to cart\n";
	}
	else if (options == 'y' || options == 'Y')
	{
		fin.close();
		fin.open("salons.txt");
		for (int j = 0; j < numberofrecords; j++)
		{
			if (j == salon_selection)
			{
				fin.getline(temp, 149);
				fout << "Name: " << temp << "\n";
				fin.getline(temp, 149);
				fout << "Address: " << temp << "\n";
				fin >> price[j][0];
				fout << "Price for Mehndi Make-up: " << price[j][0] << "\n";
				fin >> price[j][1];
				fout << "Price for Barat Make-up: " << price[j][1] << "\n";
				fin >> price[j][2];
				fin.ignore();
				fout << "Price for Walima Make-up: " << price[j][2] << "\n";
				fin.getline(temp, 149);
				fout << "Contact No: " << temp << "\n";
				fin.getline(temp, 149);
				fout << "Stars: " << temp << "\n";
				fin.getline(temp, 149);
				fout << "Rating: " << temp << "\n";
				fin.getline(temp, 149);
				fout << "-------------------------------\nTotal price will be : " << price[j][0] + price[j][1] + price[j][2] << "\n-------------------------------\n";
				break;
			}
			else
			{
				for (int i = 0; i < 9; i++)
				{
					fin.getline(temp, 99);
				}
			}
		}
	}
	cart.addANewEntry(price[salon_selection][0] + price[salon_selection][1] + price[salon_selection][2]);
	for (int i = 0; i < numberofrecords; i++)
	{
		delete[]price[i];
	}
	delete[]price;
	fin.close();
}

void AddToCartMode::phAndMM(ofstream &fout)
{
	fout << "\n\nPhotography And Movie Making:\n";
	char arr[150], options;
	double *price;
	int package_selection = 0, numberofrecords=0;
	ifstream fin;
	price = countrecords(fin, "PhAndMM.txt", numberofrecords, 11, 2);

	fin.getline(arr, 149);
	cout << "Name: " << arr << "\n";
	fin.getline(arr, 149);
	cout << "Address: " << arr << "\n";
	for (int j = 0; j < numberofrecords; j++)
	{
		cout << "package no: " << j + 1 << "\nPackage is: \n";
		for (int i = 0; i < 11; i++)
		{
			if (i == 9)
			{
				fin >> price[j];
				fin.ignore();
				cout << "Price is: " << price[j] << "\n";
			}
			else
			{
				fin.getline(arr, 149);
				cout << arr << "\n";
			}
		}
	}
	fin.close();
	cout << "Which package do you want?: ";
	cin >> package_selection;
	cout << "Its price will be " << price[package_selection - 1] << "\nDo you want to add it?(Y for yes, N for no):\n";
	cin >> options;
	if (options == 'Y' || options == 'y')
	{
		cart.addANewEntry(price[package_selection - 1]);
		fin.open("PhAndMM.txt");
		fin.getline(arr, 149);
		fout << "Name: " << arr << "\n";
		fin.getline(arr, 149);
		fout << "Address: " << arr << "\n";
		for (int j = 0; j <= package_selection; j++)
		{
			for (int i = 0; i < 11; i++)
			{
				if (j == package_selection - 1)
				{
					if (i == 9)
					{
						fout << "Price is: " << price[j] << "\n";
					}
					else
					{
						fin.getline(arr, 149);
						fout << arr << "\n";
					}
				}
				else
				{
					fin.getline(arr, 149);
				}
			}
		}
	}
	fin.close();
	fout << "-------------------------------\nTotal Amount for Photography: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	delete[]price;
}

void AddToCartMode::dresses(ofstream &fout)
{
	fout << "\n\nDresses:\n";
	char arr[150], options;
	double *price;
	int dress_selected = 0, numberofrecords=0;
	ifstream fin;
	price = countrecords(fin, "Dresses.txt", numberofrecords, 3, 1);

	fin.getline(arr, 149);
	cout << "Botiuqe Name: " << arr << "\n";
	for (int j = 0; j < numberofrecords; j++)
	{
		cout << "Dress no: " << j + 1 << "\n";
		fin.getline(arr, 149);
		cout << "Dress type: " << arr << "\n";
		fin >> price[j];
		fin.ignore();
		cout << "Price: " << price[j] << "\n";
		fin.getline(arr, 149);
		cout << arr << "\n";
	}
	fin.close();
	cout << "Which dresses you liked? ";
	cin >> dress_selected;
	cout << "Price will be " << price[dress_selected - 1] << "\nYou want it?(Y for yes, N for no): ";
	cin >> options;
	if (options == 'Y' || options == 'y')
	{
		cart.addANewEntry(price[dress_selected - 1]);
		fin.open("Dresses.txt");
		fin.getline(arr, 149);
		fout << "Botiuqe Name: " << arr << "\n";
		for (int j = 0; j <= dress_selected; j++)
		{
			if (j == dress_selected - 1)
			{
				for (int i = 0; i < 3; i++)
				{
					if (i == 0)
					{
						fin.getline(arr, 149);
						fout << "Dress type: " << arr << "\n";
					}
					else if (i == 1)
					{
						fin >> price[j];
						fin.ignore();
						fout << "Price: " << price[j] << "\n";
					}
					else
					{
						fin.getline(arr, 149);
					}
				}
			}
			else
			{
				for (int i = 0; i < 3; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fout << "-------------------------------\nTotal amount for dress is: " << cart.returnCurrentVal() << "\n-------------------------------\n";
		fin.close();
	}
	delete[]price;
}

void AddToCartMode::invitation_cards(ofstream &fout)
{
	fout << "\n\nInvitation cards: \n";
	char arr[150], options;
	double *price;
	int card_selected = 0, quantity = 0, numberofrecords=0;
	ifstream fin;
	price = countrecords(fin, "Invitation_cards.txt", numberofrecords, 3, 1);

	fin.getline(arr, 149);
	cout << "Press Name: " << arr << "\n";
	for (int j = 0; j<numberofrecords; j++)
	{
		cout << "Option no: " << j + 1 << "\n";
		fin.getline(arr, 149);
		cout << "Card type: " << arr << "\n";
		fin >> price[j];
		fin.ignore();
		cout << "Price: " << price[j] << "\n";
		fin.getline(arr, 149);
		cout << arr << "\n";
	}
	fin.close();
	cout << "Which option you liked? ";
	cin >> card_selected;
	cout << "How much cards you need? ";
	cin >> quantity;
	cout << "Price will be " << price[card_selected - 1] * quantity << "\nYou want it?(Y for yes, N for no):\n";
	cin >> options;
	if (options == 'Y' || options == 'y')
	{
		cart.addANewEntry(price[card_selected - 1] * quantity);
		fin.open("Invitation_cards.txt");
		fin.getline(arr, 149);
		fout << "Press Name: " << arr << "\n";
		for (int j = 0; j <= card_selected; j++)
		{
			if (j == card_selected - 1)
			{
				fin.getline(arr, 149);
				fout << "Card type: " << arr << "\n";
				fin >> price[j];
				fin.ignore();
				fout << "Price: " << cart.returnCurrentVal() << "\n";
				fin.getline(arr, 149);
			}
			else
			{
				for (int i = 0; i < 3; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fin.close();
	}
	fout << "-------------------------------\nTotal Amount for invitation cards will be: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	delete[]price;
}

void AddToCartMode::Hotel_rooms(ofstream &fout)
{
	fout << "\n\nHotel Rooms:\n";
	char arr[200], options;
	double *price;
	int Hotel_selected = 0, No_OF_People = 0, numberofrecords;
	ifstream fin;
	price = countrecords(fin, "Hotel_rooms.txt", numberofrecords, 8);

	for (int j = 0; j < numberofrecords; j++)
	{
		cout << "Option no: " << j + 1 << "\n";
		fin.getline(arr, 149);
		cout << "Name: " << arr << "\n";
		fin.getline(arr, 149);
		cout << "Address: " << arr << "\n";
		fin >> price[j];
		fin.ignore();
		cout << "Price: " << price[j] << "\n";
		fin.getline(arr, 149);
		cout << "Description: " << arr << "\n";
		fin.getline(arr, 149);
		cout << "Contact no: " << arr << "\n";
		fin.getline(arr, 149);
		cout << "Stars: " << arr << "\n";
		fin.getline(arr, 149);
		cout << "Ratings: " << arr << "\n";
		fin.getline(arr, 149);
		cout << arr << "\n";
	}
	fin.close();
	cout << "Which option you liked? ";
	cin >> Hotel_selected;
	cout << "How much rooms you need? ";
	cin >> No_OF_People;
	cout << "Price will be " << price[Hotel_selected - 1] * No_OF_People << "\nYou want it?(Y for yes, N for no):\n";
	cin >> options;
	if (options == 'Y' || options == 'y')
	{
		cart.addANewEntry(price[Hotel_selected - 1] * No_OF_People);
		fin.open("Hotel_rooms.txt");
		for (int j = 0; j <= Hotel_selected; j++)
		{
			if (j == Hotel_selected - 1)
			{
				fin.getline(arr, 149);
				fout << "Name: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Address: " << arr << "\n";
				fin >> price[j];
				fin.ignore();
				fout << "Price: " << price[j] << "\n";
				fin.getline(arr, 149);
				fout << "Description: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Contact no: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Stars: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Ratings: " << arr << "\n";
				fin.getline(arr, 149);
			}
			else
			{
				for (int i = 0; i < 8; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fin.close();
		fout << "-------------------------------\nTotal Amount for Hotel Rooms is: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	}
	delete[]price;
}

void AddToCartMode::florists(ofstream &fout)
{
	fout << "\n\nFlorists\n";
	char arr[150], options;
	double *price;
	int option = 0, numberofrecords=0;
	ifstream fin;

	price = countrecords(fin, "florists.txt", numberofrecords, 9);
	for (int j = 0; j<numberofrecords; j++)
	{
		cout << "Option no: " << j + 1 << "\n";
		fin.getline(arr, 149);
		cout << "Name: " << arr << "\n";
		fin.getline(arr, 149);
		cout << "Address: " << arr << "\n";
		fin.getline(arr, 149);
		cout << "Contact no: " << arr << "\n";
		fin.getline(arr, 149);
		cout << arr << "\n";
		fin.getline(arr, 149);
		cout << arr << "\n";
		fin.getline(arr, 149);
		cout << arr << "\n";
		fin.getline(arr, 149);
		cout << arr << "\n";
		fin >> price[j];
		fin.ignore();
		cout << "Price: " << price[j] << "\n";
		fin.getline(arr, 149);
		cout << arr << "\n";
	}
	fin.close();
	cout << "Which option you liked?";
	cin >> option;
	cout << "Price will be: " << price[option - 1] << "\nDo you want to add it?(Y for yes, N for no):\n";
	cin >> options;
	if (options == 'Y' || options == 'y')
	{
		cart.addANewEntry(price[option - 1]);
		fin.open("florists.txt");
		for (int j = 0; j <= option; j++)
		{
			if (j == option - 1)
			{
				fin.getline(arr, 149);
				fout << "Name: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Address: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Contact no: " << arr << "\n";
				fin >> price[j];
				fin.ignore();
				fout << "Price: " << price[j] << "\n";
				fin.getline(arr, 149);
			}
			else
			{
				for (int i = 0; i < 10; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fin.close();
		fout << "-------------------------------\nTotal Amount for Flowers is: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	}
	delete[]price;
}

void AddToCartMode::bands(ofstream &fout)
{
	fout << "\n\nBands\n";
	char arr[150], options;
	double *price;
	int option = 0, numberofrecords=0;
	ifstream fin;
	price = countrecords(fin, "Bands.txt", numberofrecords, 5);

	for (int j = 0; j<numberofrecords; j++)
	{
		cout << "Option no: " << j + 1 << "\n";
		fin.getline(arr, 149);
		cout << "Name: " << arr << "\n";
		fin.getline(arr, 149);
		cout << "Contact no: " << arr << "\n";
		fin.getline(arr, 149);
		cout << "Description: " << arr << "\n";
		fin >> price[j];
		fin.ignore();
		cout << "Price: " << price[j] << "\n";
		fin.getline(arr, 149);
		cout << arr << "\n";
	}
	fin.close();
	cout << "Which option you liked?";
	cin >> option;
	cout << "Price will be: " << price[option - 1] << "\nDo you want to add it?(Y for yes, N for no):\n";
	cin >> options;
	if (options == 'Y' || options == 'y')
	{
		cart.addANewEntry(price[option - 1]);
		fin.open("Bands.txt");
		for (int j = 0; j <= option; j++)
		{
			if (j == option - 1)
			{
				fin.getline(arr, 149);
				fout << "Name: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Contact no: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Description: " << arr << "\n";
				fin >> price[j];
				fin.ignore();
				fout << "Price: " << price[j] << "\n";
				fin.getline(arr, 149);
			}
			else
			{
				for (int i = 0; i < 5; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
	}
	fout << "-------------------------------\nTotal Amount for Band is: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	delete[]price;
}

void AddToCartMode::Transportation(ofstream &fout)
{
	fout << "\n\nTransportation:\n";
	char arr[200], options;
	double *price;
	int car_selected = 0, days = 0, numberofrecords = 0;
	ifstream fin;
	
	price = countrecords(fin, "Transportation.txt", numberofrecords, 3, 3);

	fin.getline(arr, 149);
	cout << "Name: " << arr << "\n";
	fin.getline(arr, 149);
	cout << "Address: " << arr << "\n";
	fin.getline(arr, 149);
	cout << "Contact no: " << arr << "\n";
	for (int j = 0; j<numberofrecords; j++)
	{
		cout << "Option no: " << j + 1 << "\n";
		fin.getline(arr, 149);
		cout << "Car: " << arr << "\n";
		fin >> price[j];
		fin.ignore();
		cout << "Price: " << price[j] << "\n";
		fin.getline(arr, 149);
		cout << arr << "\n";
	}
	fin.close();
	cout << "Which option you liked?: ";
	cin >> car_selected;
	cout << "How much days you will need this vehicle?: ";
	cin >> days;
	cout << "Price will be " << price[car_selected - 1] * days << "\nYou want it?(Y for yes, N for no):\n";
	cin >> options;
	if (options == 'Y' || options == 'y')
	{
		cart.addANewEntry(price[car_selected - 1] * days);
		fin.open("Transportation.txt");
		fin.getline(arr, 149);
		fout << "Name: " << arr << "\n";
		fin.getline(arr, 149);
		fout << "Address: " << arr << "\n";
		fin.getline(arr, 149);
		fout << "Contact no: " << arr << "\n";
		for (int j = 0; j <= car_selected; j++)
		{
			if (j == car_selected - 1)
			{
				fin.getline(arr, 149);
				fout << "Car: " << arr << "\n";
				fin >> price[j];
				fin.ignore();
				fout << "Price: " << price[j] << "\n";
				fin.getline(arr, 149);
			}
			else
			{
				for (int i = 0; i < 3; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fin.close();
		fout << "-------------------------------\nTotal amount for Transportation is: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	}
	delete[]price;
}

void AddToCartMode::OutputTotalToFile(ofstream &fout)
{
	fout << "-------------------------------\nGrand Total for full plan is: " << cart.returnTotal() << "\n-------------------------------\n";
}

AddToCartMode::AddToCartMode()
{
}

AddToCartMode::~AddToCartMode()
{
}