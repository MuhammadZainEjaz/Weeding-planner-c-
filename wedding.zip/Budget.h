#pragma once
#include <iostream>
using namespace std;

class Budget
{
public:
	Budget();
	~Budget();
	void setBudget(double);
	double getBudget() const;
	void setFlag(bool);
	double getPercentageOfBudget(double ) const;
	void subtractFromBudget(double);
	void addIntoBudget(double);
	bool isBudgetAvailable() const;
private:
	bool flag;
	double budget;
};