#pragma once
#include "AddToCartMode.h"
#include "GBudgetTPlan.h"
#include <iostream>

class MyPlan:public AddToCartMode, public GBudgetTPlan
{
public:
	MyPlan();
	~MyPlan();
	void menu();
private:
	char *GetNameOfCustomer();

};