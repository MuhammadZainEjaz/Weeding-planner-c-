#include <iostream>
#include <fstream>
#include "Cart.h"
#include "Budget.h"

class GBudgetTPlan
{
public:
	GBudgetTPlan();
	~GBudgetTPlan();
	void menu(ofstream &fout);

private:

	/* main Functions */
	void Wedding_halls(ofstream &fout);
	void phAndMM(ofstream &fout);
	void salons(ofstream &fout);
	void catering(ofstream &fout);
	void dresses(ofstream &fout);
	void invitation_cards(ofstream &fout);
	void florists(ofstream &fout);
	void bands(ofstream &fout);
	void Transportation(ofstream &fout);

	/* Helping functions */
	void OutputTotalToFile(ofstream &fout);
	double * countrecords(ifstream &fin, char *, int &, int, int = 0);
	void setNumberOfPeople(int);
	int getNumberOfPeople() const;
	int returnSuitableOption(double *, int, double);

	/* Members */
	Budget budget;
	int noOfPeople;
	Cart cart;
};