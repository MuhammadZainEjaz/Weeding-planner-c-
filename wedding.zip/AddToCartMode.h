#pragma once
#include <iostream>
#include <fstream>
#include "Cart.h"
using namespace std;

class AddToCartMode
{
public:
	AddToCartMode();
	~AddToCartMode();
	void menu(ofstream &fout);
private:
	void Wedding_halls(ofstream &fout);
	void catering(ofstream &fout);
	void salons(ofstream &fout);
	void phAndMM(ofstream &fout);
	void dresses(ofstream &fout);
	void invitation_cards(ofstream &fout);
	void Hotel_rooms(ofstream &fout);
	void florists(ofstream &fout);
	void bands(ofstream &fout);
	void Transportation(ofstream &fout);

	void OutputTotalToFile(ofstream &fout);
	double * countrecords(ifstream &fin, char *, int &, int, int = 0);
	Cart cart; // Composition
};