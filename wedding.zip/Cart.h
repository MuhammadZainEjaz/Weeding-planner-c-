#pragma once
#include <iostream>
using namespace std;

class Cart
{
public:
	Cart();
	~Cart();
	double *regrow(double * , int);
	void addANewEntry(double);
	double returnCurrentVal() const;
	double *returnCart() const;
	double returnTotal() const;
private:
	int index;
	double *price;
};