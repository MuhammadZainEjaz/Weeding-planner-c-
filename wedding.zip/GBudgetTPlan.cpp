#include <iostream>
#include <windows.h>
#include <fstream>
#include "GBudgetTPlan.h"
using namespace std;

GBudgetTPlan::GBudgetTPlan()
{
	noOfPeople = 0;
}

void GBudgetTPlan::menu(ofstream &fout)
{
	// Welcome Note
	cout << "Welcome To Give Budget Take plan mode\n";
	Sleep(2000);
	system("cls");

	double temp = 0;
	cout << "Enter your Budget: ";
	cin >> temp;
	budget.setBudget(temp);

	int temp1 = 0;
	cout << "Enter Number of people coming: ";
	cin >> temp1;
	setNumberOfPeople(temp1);

	int option = 0;
	// Deciding Venue
	cout << "Enter 1 for Wedding Halls\nEnter 2 for Catering\n";
	cin >> option;
	if (option == 1)
	{
		if (budget.isBudgetAvailable() == 1)
			Wedding_halls(fout);
	}
	else if (option == 2)
	{
		if (budget.isBudgetAvailable() == 1)
			catering(fout);
	}
	

	// Decision about Movie and Photography
	if (budget.isBudgetAvailable() == 1)
		phAndMM(fout);

	// Decision about saloons
	if (budget.isBudgetAvailable() == 1)
		salons(fout);

	// Decision about Dresses
	if (budget.isBudgetAvailable() == 1)
		dresses(fout);

	// Decision about invitation cards
	if (budget.isBudgetAvailable() == 1)
		invitation_cards(fout);

	// Decision about florists
	if (budget.isBudgetAvailable() == 1)
		florists(fout);

	// Decision about bands
	if (budget.isBudgetAvailable() == 1)
		bands(fout);

	// Decision about Transportation
	if (budget.isBudgetAvailable() == 1)
		Transportation(fout);

	OutputTotalToFile(fout);

}

double * GBudgetTPlan::countrecords(ifstream &fin, char * nameoffile, int & numberOfRecords, int recordlength, int tosubtract)
{
	char arr[150];
	fin.open(nameoffile);
	for (numberOfRecords = 0; !fin.eof(); numberOfRecords++)
	{
		fin.getline(arr, 149);
	}
	fin.close();
	fin.open(nameoffile);
	numberOfRecords -= tosubtract;
	numberOfRecords /= recordlength;
	double *price = new double[numberOfRecords];
	return price;
}

void GBudgetTPlan::OutputTotalToFile(ofstream &fout)
{
	fout << "\n\n-------------------------------\nTotal budget given was: " << long(cart.returnTotal()+budget.getBudget()) << "\n-------------------------------\n";
	fout << "-------------------------------\nGrand Total for full plan is: " << cart.returnTotal() << "\n-------------------------------\n";
	fout << "-------------------------------\nRemaining budget is: " << budget.getBudget() << "\n-------------------------------\n";
}

void GBudgetTPlan::setNumberOfPeople(int val)
{
	noOfPeople = val;
}

int GBudgetTPlan::getNumberOfPeople() const
{
	return noOfPeople;
}

int GBudgetTPlan::returnSuitableOption(double *price, int size, double val)
{
	double *arr = new double[size + 1];
	for (int i = 0; i < size; i++)
	{
		arr[i] = price[i];
	}
	arr[size] = val;
	int min = 0, selectedIndex = 0;
	double temp = 0;
	for (int i = 0; i < size; i++)
	{
		min = i;
		for (int j = i + 1; j < size + 1; j++)
		{
			if (arr[j] < arr[min])
			{
				min = j;
			}
		}
		temp = arr[i];
		arr[i] = arr[min];
		arr[min] = temp;
	}
	for (int i = 0; i < size + 1; i++)
	{
		if (val == arr[i])
		{
			if (i == 0)
			{
				if (val == arr[i + 1])
					selectedIndex = i + 1;
			}
			else if (i > 0)
				selectedIndex = i - 1;
		}
	}
	for (int i = 0; i < size + 1; i++)
	{
		if (price[i] == arr[selectedIndex])
			return i;
	}
}

void GBudgetTPlan::Wedding_halls(ofstream &fout)
{
	int hall_selection = 0, numberOfRecords = 0;
	double budgetForHallsPerHead = budget.getPercentageOfBudget(40) / noOfPeople;
	double *price;
	char arr[150];

	ifstream fin;
	price = countrecords(fin, "halls.txt", numberOfRecords, 8);

	for (int j = 0; j < numberOfRecords; j++)
	{
		for (int i = 0; i < 8; i++)
		{
			if (i == 2)
			{
				fin >> price[j];
				fin.ignore();
			}
			else
				fin.getline(arr, 149);
		}
	}
	fin.close();
	if (budgetForHallsPerHead >= price[numberOfRecords - 1])
	{
		hall_selection = returnSuitableOption(price, numberOfRecords, budgetForHallsPerHead);

		cart.addANewEntry(price[hall_selection] * noOfPeople);
		budget.subtractFromBudget(cart.returnCurrentVal());
		fin.open("halls.txt");
		fout << "Hall Details:\n";
		for (int j = 0; j <= hall_selection; j++)
		{
			if (j == hall_selection)
			{
				fin.getline(arr, 149);
				fout << "Name: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Address: " << arr << "\n";
				fin >> price[j];
				fin.ignore();
				fout << "Price Per Head(Rs.): " << price[j] << "\n";
				fin.getline(arr, 149);
				fout << "Description: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Contact No: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Stars: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Rating: " << arr << "\n";
				fin.getline(arr, 149);
				fout << arr << "\n";
				break;
			}
			else
			{
				for (int i = 0; i < 8; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fout << "Total amount for Halls is: " << cart.returnCurrentVal() << "\n";
		fout << arr << "\n";
		fin.close();
	}
	else
	{
		fout << "Soory but your budget is too Low\n";
		budget.setFlag(false);
	}
	delete[] price;
}

void GBudgetTPlan::phAndMM(ofstream &fout)
{
	char arr[150];
	double *price, budgetForMMandP = budget.getPercentageOfBudget(20);
	int package_selection = 0, numberofrecords=0;
	ifstream fin;
	price = countrecords(fin, "PhAndMM.txt", numberofrecords, 11, 2);

	fin.getline(arr, 149);
	fin.getline(arr, 149);
	for (int j = 0; j < numberofrecords; j++)
	{
		for (int i = 0; i < 11; i++)
		{
			if (i == 9)
			{
				fin >> price[j];
				fin.ignore();
			}
			else
			{
				fin.getline(arr, 149);
			}
		}
	}
	fin.close();

	if (budgetForMMandP >= price[numberofrecords - 1])
	{
		package_selection = returnSuitableOption(price, numberofrecords, budgetForMMandP);
		fin.open("PhAndMM.txt");
		fout << "\n\nPhotography And Movie Making:\n";
		fin.getline(arr, 149);
		fout << "Name: " << arr << "\n";
		fin.getline(arr, 149);
		fout << "Address: " << arr << "\n";
		for (int j = 0; j <= package_selection; j++)
		{
			for (int i = 0; i < 11; i++)
			{
				if (j == package_selection)
				{
					if (i == 9)
					{
						fout << "Price is: " << price[j] << "\n";
					}
					else
					{
						fin.getline(arr, 149);
						fout << arr << "\n";
					}
				}
				else
				{
					fin.getline(arr, 149);
				}
			}
		}
		fin.close();
		cart.addANewEntry(price[package_selection]);
		budget.subtractFromBudget(price[package_selection]);
		fout << "-------------------------------\nTotal Amount for Photography: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	}
	else
	{
		fout << "Budget is Low\n";
	}

	delete[]price;
}

void GBudgetTPlan::salons(ofstream &fout)
{
	int class_salons = 0;
	double **price, *price2, budgetForSaloons = budget.getPercentageOfBudget(20);
	int salon_selection = 0, total = 0, numberofrecords;
	char options = '\0', temp[100];
	ifstream fin;
	fin.open("salons.txt");
	for (numberofrecords = 0; !fin.eof(); numberofrecords++)
	{
		fin.getline(temp, 99);
	}
	numberofrecords /= 9;
	fin.close();
	fin.open("salons.txt");
	price = new double*[numberofrecords];
	price2 = new double[numberofrecords];

	for (int j = 0; j < numberofrecords; j++)
	{
		price[j] = new double[3];
		fin.getline(temp, 149);
		fin.getline(temp, 149);
		fin >> price[j][0];
		fin >> price[j][1];
		fin >> price[j][2];
		fin.ignore();
		fin.getline(temp, 149);
		fin.getline(temp, 149);
		fin.getline(temp, 149);
		fin.getline(temp, 149);
		price2[j] = price[j][0] + price[j][1] + price[j][2];
	}
	fin.close();
	fin.open("salons.txt");
	if (budgetForSaloons >= price2[numberofrecords - 1])
	{
		salon_selection = returnSuitableOption(price2, numberofrecords, budgetForSaloons);
		system("cls");
		fout << "\n\nSalons:\n";
		for (int j = 0; j < numberofrecords; j++)
		{
			if (j == salon_selection)
			{
				fin.getline(temp, 149);
				fout << "Name: " << temp << "\n";
				fin.getline(temp, 149);
				fout << "Address: " << temp << "\n";
				fin >> price[j][0];
				fout << "Price for Mehndi Make-up: " << price[j][0] << "\n";
				fin >> price[j][1];
				fout << "Price for Barat Make-up: " << price[j][1] << "\n";
				fin >> price[j][2];
				fin.ignore();
				fout << "Price for Walima Make-up: " << price[j][2] << "\n";
				fin.getline(temp, 149);
				fout << "Contact No: " << temp << "\n";
				fin.getline(temp, 149);
				fout << "Stars: " << temp << "\n";
				fin.getline(temp, 149);
				fout << "Rating: " << temp << "\n";
				fin.getline(temp, 149);
				fout << "-------------------------------\nTotal price for Saloons is: " << price[j][0] + price[j][1] + price[j][2] << "\n-------------------------------\n";
				break;
			}
			else
			{
				for (int i = 0; i < 9; i++)
				{
					fin.getline(temp, 99);
				}
			}
		}
		cart.addANewEntry(price2[salon_selection]);
		budget.subtractFromBudget(price2[salon_selection]);
	}
	else
	{
		fout << "Budget is Low\n";
		budget.setFlag(false);
	}
	
	fin.close();
	for (int i = 0; i < numberofrecords; i++)
	{
		delete[]price[i];
	}
	delete[]price;
	fin.close();
}

void GBudgetTPlan::catering(ofstream &fout)
{
	double *price_items, grandTotal = 0, total[53];
	int quantity[53], numberofrecords = 0;
	char **arr;
	ifstream fin;
	price_items = countrecords(fin, "Wedding_items.txt", numberofrecords, 2);
	arr = new char*[numberofrecords];
	for (int i = 0; i < numberofrecords; i++)
	{
		arr[i] = new char[100];
		fin.getline(arr[i], 99);
		fin >> price_items[i];
		fin.ignore();
		if (i < 18)
		{
			quantity[i] = noOfPeople;
			total[i] = price_items[i] * quantity[i];
		}
		else
		{
			total[i] = price_items[i];
			quantity[i] = 1;
		}
	}
	for (int i = 0; i < numberofrecords; i++)
	{
		grandTotal += total[i];
	}
	if (grandTotal <= budget.getPercentageOfBudget(50))
	{
		cart.addANewEntry(grandTotal);
		budget.subtractFromBudget(grandTotal);
		fout << "Catering Details:\n";
		for (int i = 0; i < numberofrecords; i++)
		{
			fout << "Item: " << arr[i] << "   Price per Item: " << price_items[i] << "   Quantity: " << quantity[i] << "   Total Price: " << total[i] << "\n";
		}
		fout << "-------------------------------\nTotal amount: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	}
	else
	{
		fout << "Total amount: 0 Not Enough budget.\n";
	}

	for (int i = 0; i < numberofrecords; i++)
	{
		delete[]arr[i];
	}
	delete[]arr;
	delete[]price_items;
}


void GBudgetTPlan::dresses(ofstream &fout)
{
	fout << "\n\nDresses:\n";
	char arr[150], options;
	double *price, budgetForDresses;
	int dress_selected = 0, numberofrecords = 0;
	ifstream fin;
	price = countrecords(fin, "Dresses.txt", numberofrecords, 3, 1);

	fin.getline(arr, 149);
	for (int j = 0; j < numberofrecords; j++)
	{
		fin.getline(arr, 149);
		fin >> price[j];
		fin.ignore();
		fin.getline(arr, 149);
	}
	fin.close();
	budgetForDresses = budget.getPercentageOfBudget(30);
	if (budgetForDresses >= price[numberofrecords - 1])
	{
		dress_selected = returnSuitableOption(price, numberofrecords, budgetForDresses);
		fin.open("Dresses.txt");
		fin.getline(arr, 149);
		fout << "Botiuqe Name: " << arr << "\n";
		for (int j = 0; j <= dress_selected; j++)
		{
			if (j == dress_selected)
			{
				fin.getline(arr, 149);
				fout << "Dress type: " << arr << "\n";
				fin >> price[j];
				fin.ignore();
				fout << "Price: " << price[j] << "\n";
				fin.getline(arr, 149);
			}
			else
			{
				for (int i = 0; i < 3; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fout << "-------------------------------\nTotal amount for dress is: " << cart.returnCurrentVal() << "\n-------------------------------\n";
		fin.close();
		cart.addANewEntry(price[dress_selected]);
		budget.subtractFromBudget(price[dress_selected]);
	}
	delete[]price;
}

void GBudgetTPlan::invitation_cards(ofstream &fout)
{
	char arr[150];
	double *price, budgetForInvitationCards=0;
	int card_selected = 0, quantity = noOfPeople, numberofrecords = 0;
	ifstream fin;
	price = countrecords(fin, "Invitation_cards.txt", numberofrecords, 3, 1);
	fin.getline(arr, 149);
	for (int j = 0; j<numberofrecords; j++)
	{
		fin.getline(arr, 149);
		fin >> price[j];
		fin.ignore();
		fin.getline(arr, 149);
	}
	fin.close();
	budgetForInvitationCards = budget.getPercentageOfBudget(20) * quantity;
	if (budgetForInvitationCards >= price[numberofrecords - 1])
	{
		card_selected = returnSuitableOption(price, numberofrecords, budgetForInvitationCards);
		cart.addANewEntry(price[card_selected] * quantity);
		budget.subtractFromBudget(price[card_selected] * quantity);
		fin.open("Invitation_cards.txt");
		fout << "\n\nInvitation cards: \n";
		fin.getline(arr, 149);
		fout << "Press Name: " << arr << "\n";
		for (int j = 0; j <= card_selected; j++)
		{
			if (j == card_selected)
			{
				fin.getline(arr, 149);
				fout << "Card type: " << arr << "\n";
				fin >> price[j];
				fin.ignore();
				fout << "Price: " << cart.returnCurrentVal() << "\n";
				fin.getline(arr, 149);
			}
			else
			{
				for (int i = 0; i < 3; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fin.close();
		fout << "-------------------------------\nTotal Amount for invitation cards will be: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	}
	else
		fout << "Budget low\n";
	delete[]price;
}

void GBudgetTPlan::florists(ofstream &fout)
{
	char arr[150];
	double *price, budgetForFlorists=budget.getPercentageOfBudget(30);
	int option = 0, numberofrecords = 0;
	ifstream fin;

	price = countrecords(fin, "florists.txt", numberofrecords, 9);
	for (int j = 0; j<numberofrecords; j++)
	{
		fin.getline(arr, 149);
		fin.getline(arr, 149);
		fin.getline(arr, 149);
		fin.getline(arr, 149);
		fin.getline(arr, 149);
		fin.getline(arr, 149);
		fin.getline(arr, 149);
		fin >> price[j];
		fin.ignore();
		fin.getline(arr, 149);
	}
	fin.close();
	if (budgetForFlorists >= price[numberofrecords - 1])
	{
		option = returnSuitableOption(price, numberofrecords, budgetForFlorists);
		cart.addANewEntry(price[option]);
		budget.subtractFromBudget(price[option]);
		fout << "\n\nFlorists\n";
		fin.open("florists.txt");
		for (int j = 0; j <= option; j++)
		{
			if (j == option)
			{
				fin.getline(arr, 149);
				fout << "Name: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Address: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Contact no: " << arr << "\n";
				fin >> price[j];
				fin.ignore();
				fout << "Price: " << price[j] << "\n";
				fin.getline(arr, 149);
			}
			else
			{
				for (int i = 0; i < 10; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fin.close();
		fout << "-------------------------------\nTotal Amount for Flowers is: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	}
	delete[]price;
}

void GBudgetTPlan::bands(ofstream &fout)
{
	char arr[150];
	double *price, budgetForBands=budget.getPercentageOfBudget(30);
	int option = 0, numberofrecords = 0;
	ifstream fin;
	price = countrecords(fin, "Bands.txt", numberofrecords, 5);

	for (int j = 0; j<numberofrecords; j++)
	{
		fin.getline(arr, 149);
		fin.getline(arr, 149);
		fin.getline(arr, 149);
		fin >> price[j];
		fin.ignore();
		fin.getline(arr, 149);
	}
	fin.close();
	if (budgetForBands >= price[numberofrecords - 1])
	{
		option = returnSuitableOption(price, numberofrecords, budgetForBands);
		cart.addANewEntry(price[option]);
		budget.subtractFromBudget(price[option]);
		fin.open("Bands.txt");
		fout << "\n\nBands\n";
		for (int j = 0; j <= option; j++)
		{
			if (j == option)
			{
				fin.getline(arr, 149);
				fout << "Name: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Contact no: " << arr << "\n";
				fin.getline(arr, 149);
				fout << "Description: " << arr << "\n";
				fin >> price[j];
				fin.ignore();
				fout << "Price: " << price[j] << "\n";
				fin.getline(arr, 149);
			}
			else
			{
				for (int i = 0; i < 5; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fout << "-------------------------------\nTotal Amount for Band is: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	}
	fin.close();
	delete[]price;
}

void GBudgetTPlan::Transportation(ofstream &fout)
{
	char arr[200], options;
	double *price, budgetForTransportation=budget.getPercentageOfBudget(40)*2;
	int car_selected = 0, days = 2, numberofrecords = 0;
	ifstream fin;

	price = countrecords(fin, "Transportation.txt", numberofrecords, 3, 3);

	fin.getline(arr, 149);
	fin.getline(arr, 149);
	fin.getline(arr, 149);
	for (int j = 0; j<numberofrecords; j++)
	{
		fin.getline(arr, 149);
		fin >> price[j];
		fin.ignore();
		fin.getline(arr, 149);
	}
	fin.close();
	if (budgetForTransportation >= price[numberofrecords - 1])
	{
		car_selected = returnSuitableOption(price, numberofrecords, budgetForTransportation);
		cart.addANewEntry(price[car_selected] * days);
		budget.subtractFromBudget(price[car_selected] * days);
		fin.open("Transportation.txt");
		fout << "\n\nTransportation:\n";
		fin.getline(arr, 149);
		fout << "Name: " << arr << "\n";
		fin.getline(arr, 149);
		fout << "Address: " << arr << "\n";
		fin.getline(arr, 149);
		fout << "Contact no: " << arr << "\n";
		for (int j = 0; j <= car_selected; j++)
		{
			if (j == car_selected)
			{
				fin.getline(arr, 149);
				fout << "Car: " << arr << "\n";
				fin >> price[j];
				fin.ignore();
				fout << "Price: " << price[j] << "\n";
				fin.getline(arr, 149);
			}
			else
			{
				for (int i = 0; i < 3; i++)
				{
					fin.getline(arr, 149);
				}
			}
		}
		fin.close();
		fout << "-------------------------------\nTotal amount for Transportation is: " << cart.returnCurrentVal() << "\n-------------------------------\n";
	}
	delete[]price;
}

GBudgetTPlan::~GBudgetTPlan()
{
}