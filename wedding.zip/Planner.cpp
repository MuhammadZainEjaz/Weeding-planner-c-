#include <iostream>
#include <fstream>
#include "Planner.h"
#include <Windows.h>
using namespace std;


MyPlan::MyPlan()
{
}

char *MyPlan::GetNameOfCustomer()
{
	char *arr = new char[100];
	cout << "Please Enter your Name: ";
	cin.getline(arr, 99);
	for (int i = 0;; i++)
	{
		if (arr[i] == '\0')
		{
			arr[i++] = '.';
			arr[i++] = 't';
			arr[i++] = 'x';
			arr[i++] = 't';
			arr[i] = '\0';
			break;
		}
	}
	return arr;
}

void MyPlan::menu()
{
	int choice = 0;

	// Welcome Note
	cout << "Welcome To Wedding Planner Program\n";
	Sleep(2000);
	system("cls");

	char *fileName = GetNameOfCustomer();
	ofstream fout;
	fout.open(fileName);
	system("cls");


	for (;;)
	{
		cout << "Press 1 to Enter in Add To Cart Mode\nPress 2 to Enter in Give Budget Get Plan mode\n";
		cin >> choice;
		system("cls");
		if (choice == 1)
		{
			AddToCartMode::menu(fout);
			break;
		}
		else if (choice == 2)
		{
			//cout << "This mode is under proccess. Coming soon\n";
			GBudgetTPlan::menu(fout);
			break;
		}
		else
			cout << "Invalid Input. Input again\n";
	}
}

MyPlan::~MyPlan()
{
}