#include <iostream>
#include "Cart.h"
using namespace std;

Cart::Cart()
{
	index = 0;
	price = NULL;
}

double *Cart::regrow(double *arr, int size)
{
	double * temp = new double[size + 1];
	for (int i = 0; i < size; i++)
	{
		temp[i] = arr[i];
	}
	delete[] arr;
	arr = temp;
	return arr;
}

double *Cart::returnCart() const
{
	return price;
}

double Cart::returnCurrentVal() const
{
	return price[index - 1];
}

double Cart::returnTotal() const
{
	long temp = 0;
	for (int i = 0; i < index; i++)
	{
		temp += price[i];
	}
	return temp;
}

void Cart::addANewEntry(double val)
{
	price = regrow(price, index);
	price[index++] = val;
}

Cart::~Cart()
{
	delete[]price;
}